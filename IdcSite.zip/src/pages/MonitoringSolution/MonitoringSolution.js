import Vue from 'vue'
import App from './MonitoringSolution.vue'

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#index')
