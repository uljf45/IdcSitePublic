import Vue from 'vue'
import App from './GameSolution.vue'

Vue.config.productionTip = false

new Vue({
  render: h => h(App),
}).$mount('#index')
