<template>
    <div class="single-banner" :class="[{'single-banner--bg2': bgImgType == 2}]">
        <div class="single-banner-inner" >
            <section class="txt">`
                <h1 v-text="title"></h1>
                <p v-html="content"></p>
                <idc-button :text="'立即咨询'"></idc-button>
            </section>
            <section class="pic">
                <img src="../../../public/imgs/fangyu-large.png" alt="">
            </section> 
        </div>
    </div>
</template>
<script>
import IdcButton from '@/components/common/IdcButton.vue'

export default {
    name: 'SingleBanner',
    props: {
        title: {
            type: String,
            default: ''
        },
        content: {
            type: String,
            default: ''
        },
        bgImgType: {
            type: Number,
            default: 1, // 1. '../../../public/imgs/single-banner.png'   2. '../../../public/imgs/single-banner2.png'
        }
    },
    components: {
        IdcButton
    }
}
</script>
<style lang="scss">
    .single-banner {
        min-width: 1024px;
        height: 698px;
        background: url('../../../public/imgs/single-banner.png') no-repeat center top;
        color: #e1e1e2;
    }

    .single-banner--bg2 {
        background: url('../../../public/imgs/single-banner.png') no-repeat center top;
    }

    .single-banner-inner {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        width: 64%;
        min-width: 1024px;
        margin: 0 auto;
        padding-top: 140px;  
        .txt {
            flex: 0 1 660px;
        }
        .pic {
            flex: 0 1 280px;
        }
        h1 {
            text-align: left;
            font-weight: normal;
            font-size: 76px;
        }
        p {
            line-height: 42px;
            margin-top: 10px;
            text-align: left;
            font-size: 22px;
        }
    }

</style>