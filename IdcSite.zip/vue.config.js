const utils  = require('./utils/utils');

module.exports = {
  publicPath: './', 
  pages: utils.getPages() 
}
